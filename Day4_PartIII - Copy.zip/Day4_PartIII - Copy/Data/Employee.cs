﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day4_PartIII
{
    public class Employee
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public DateTime BirthYear { get; set; }

       
    }
}
