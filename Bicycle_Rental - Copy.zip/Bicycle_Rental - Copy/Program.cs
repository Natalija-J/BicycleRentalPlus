﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Bicycle_Rental
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Bicycle> bikes1 = new List<Bicycle>();
            List<User> renters = new List<User>();

            Console.WriteLine("Avaiable Bikes: ");
            Console.WriteLine();
            bikes1.Add(new Bicycle(01, "Norco Search XR A1" ));
            bikes1.Add(new Bicycle(02, "Trek Emonda SLR 9"));
            bikes1.Add(new Bicycle(03, "Trek Rail 9.9" ));
            bikes1.Add(new Bicycle(04, "Norco Sight C1" ));
            bikes1.Add(new Bicycle(05, "Giant ATX" ));
            bikes1.Add(new Bicycle(06, "GT Grade Elite" ));
            Console.WriteLine();
                       
            Console.Write("Enter bicycle number to rent: ");
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter rental period (hours): ");
            int time = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Enter your email: ");
            string email = Console.ReadLine();
            Console.WriteLine();

            renters.Add(new User(email, time, number));
            Bicycle bikeToRent = bikes1.FirstOrDefault(b => b.IdNumber == number);
            if (bikeToRent != null)
            {
                Console.WriteLine($"You have successfully rented a bike: {number}");
            }
            

        }
    }
}
