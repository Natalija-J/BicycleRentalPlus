﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bicycle_Rental
{
    class User
    {
        //for now each user will have an email without stipulation of symbols
        public string Email;
        //each user chooses the time for how long they want to rent a bicycle
        public int RentTime;

        public Bicycle RentalBike;

        public User()
        {
           
        }
        public User(string _email, int _time, int _number)
        {
            Email = _email;
            RentTime = _time;
            RentalBike.IdNumber = _number;
        }

        
    }
}
