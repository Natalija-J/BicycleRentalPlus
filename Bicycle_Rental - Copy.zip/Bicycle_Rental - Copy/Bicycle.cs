﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bicycle_Rental
{
    class Bicycle
    {
        /*
         * Requirements:
                ● Information about bicycles (name and number) is stored in a list (predefined
                list);
                ● Reservations (user email, rental period, selected bicycle) are stored in a list;
                ● To rent a bicycle user specifies bike’s number, rental period and e-mail;
                ● Check if the entered bike’s number exists in a list;
                ● Multiple reservations can be done (after the reservation ask if user would like
                to make another reservation e.g. for another user, using different email)
                ● Object-oriented approach (creating multiple classes to separate logic)

         */
        public int IdNumber;
        public string Model;
        public List<Bicycle> Bicycles = new List<Bicycle>();

        public Bicycle(int _idN, string _model)
        {
            IdNumber = _idN;
            Model = _model;
            Console.WriteLine($"{IdNumber} - { Model}");
        }
        public void PrintBikeInfo()
        {
            Console.WriteLine($"{IdNumber} - { Model}");
        }
        //private List<Bicycle> Bicycles = new List<Bicycle>();


        //public Bicycle(string _model, int _id)
        //{
        //    Model = _model;
        //    IdNumber = _id;
        //}
        //public Bicycle()
        //{

        //}

        //public void PrintInfo()
        //{
        //    Console.Write($"{IdNumber}: '{Model}'");
        //    Console.WriteLine();
        //}

        //public string AddBicycle(string _model, int _id)
        //{
        //    var bike = new Bicycle()
        //    {
        //        Model = _model,
        //        IdNumber = _id
        //    };

        //    Bicycles.Add(bike);
        //    return "Success, bicycle was added.";

        //}
        public string ChecksForBike(string model, int idNumber)
        {
            Bicycle bike = Bicycles.FirstOrDefault(bike => bike.IdNumber == idNumber);
            
                if (bike == null)
                {
                    return $"There is no bicycle under this {idNumber} ID Number!";
                }
                
                return $"You have successfully rented a bike: {model}";
            
            return "";
        }
    }
}
